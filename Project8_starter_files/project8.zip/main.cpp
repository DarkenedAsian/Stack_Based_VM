#include <iostream>
#include "Parse.h"
#include "Interpret.h"
using namespace std;

int main(void) {
   set_input("test_grader.blip");
   run();
}
