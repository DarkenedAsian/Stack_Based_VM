//
// Created by DarkenedAsian on 5/1/2022.
//

#ifndef MAIN_CPP_INTERPRET_H
#define MAIN_CPP_INTERPRET_H
#include "Parse.h"
#include <unordered_map>
#include <vector>
#include <stack>

void run(void);

#endif //MAIN_CPP_INTERPRET_H

